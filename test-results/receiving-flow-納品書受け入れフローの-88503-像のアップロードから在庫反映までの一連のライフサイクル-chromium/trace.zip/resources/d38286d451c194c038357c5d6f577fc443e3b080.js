(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_05k~79b._.js","static/chunks/0sv3_next_dist_compiled_next-devtools_index_0fbk3u3.js","static/chunks/0sv3_next_dist_compiled_react-dom_0fbtl50._.js","static/chunks/0sv3_next_dist_compiled_react-server-dom-turbopack_03c62c5._.js","static/chunks/0sv3_next_dist_compiled_02h8e9m._.js","static/chunks/0sv3_next_dist_client_0pg_w38._.js","static/chunks/0sv3_next_dist_0k7jmmn._.js","static/chunks/0i4a_@swc_helpers_cjs_0hvz.20._.js"],
    source: "entry"
});
