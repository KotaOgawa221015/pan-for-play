(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_0-uvx.y._.js","static/chunks/node_modules__pnpm_0h7kc~f._.js"],
    source: "dynamic"
});
