(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__02nfq85._.css","static/chunks/0sv3_next_dist_12kjv4j._.js"],
    source: "dynamic"
});
